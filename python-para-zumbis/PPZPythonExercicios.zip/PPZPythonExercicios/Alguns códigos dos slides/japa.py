def desconto(preço):
    return 0.50*preço
