# altere o código abaixo
# para imprimir de 1 até um número lido
x = 0
fim = int(input('Fim: '))
while x <= fim:
	print(x)
	x = x + 2

