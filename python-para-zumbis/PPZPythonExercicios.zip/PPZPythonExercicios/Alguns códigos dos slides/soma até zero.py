soma = 0
while True:
  x = int(input('n (zero sai): '))
  if x == 0:
    break
  soma = soma + x
print (f'Soma: {soma}')

