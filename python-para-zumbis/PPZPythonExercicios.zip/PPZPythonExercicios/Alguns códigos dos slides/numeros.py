f = open(r'c:/Users/fmasa/x.txt', 'w')
for linha in range(1, 101):
  f.write(f'{linha}\n')
f.close()

  
