a = int(input("Primeiro valor: "))
b = int(input("Segundo valor: "))
if a > b:
  print ("O primeiro número é o maior!")

if b > a:
  print ("O segundo número é o maior!")
