usuário = input('Usuário: ')
senha = input('Senha: ')
while usuário == senha:
  print('Senha deve ser diferente do Usuário')
  usuário = input('Usuário: ')
  senha = input('Senha: ')
