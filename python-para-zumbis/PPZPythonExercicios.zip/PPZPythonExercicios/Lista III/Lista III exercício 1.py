nota = float(input('Digite uma nota: '))
while nota < 0 or nota > 10:
  print ('Notas entre 0 e 10: ')
  nota = float(input('Digite uma nota: '))
