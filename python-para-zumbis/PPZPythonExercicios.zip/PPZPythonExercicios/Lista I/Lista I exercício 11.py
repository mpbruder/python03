print (len(str(2**1000000)))
