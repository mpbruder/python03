m = int(input('Metros: '))
print (f'Milímetros: {m*1000}')
