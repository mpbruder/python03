c = float(input('Celsius: '))
f = 9*c/5 + 32
print (f'{f:.2f} Fahrenheit')
