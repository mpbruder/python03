d = float(input('Distância km: '))
v = float(input('Vel. média km/h: '))
t = d / v
print (f'Tempo: {t:.1f}')
