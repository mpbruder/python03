km = float(input('Km rodados: '))
dias = int(input('Dias: '))
preço = 60*dias + 0.15*km
print (f'R$ {preço:.2f}')
