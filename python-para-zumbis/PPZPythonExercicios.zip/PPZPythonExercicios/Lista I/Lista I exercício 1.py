n1 = int(input('1o número: '))
n2 = int(input('2o número: '))
print (n1 + n2)
